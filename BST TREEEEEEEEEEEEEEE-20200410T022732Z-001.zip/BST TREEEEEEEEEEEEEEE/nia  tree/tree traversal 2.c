#include<stdio.h>
int a[]={0,11,6,19,4,8,17,43,0,5,0,10,0,0,31,49};
void inOrder(int i, int Size){
	if (a[i]== 0  || i>=Size)
		return;
	else{
		int left=2*i;
		int right=2*i+1;
		inOrder(left,Size);
		printf("%d ", a[i]);

		inOrder(right,Size);

		}
}
void postOrder(int i, int Size){


        if (a[i]== 0  || i>=Size)
		return;
	else{
		int left=2*i;
		int right=2*i+1;
		postOrder(left,Size);
		postOrder(right,Size);
        printf("%d ", a[i]);

		}

    }
    void preOrder(int i, int Size){


        if (a[i]== 0  || i>=Size)
		return;
	else{
		int left=2*i;
		int right=2*i+1;
        printf("%d ", a[i]);
		preOrder(left,Size);
		preOrder(right,Size);


		}

    }

int main()
{
    puts("IN:");
    inOrder(1,16);
    puts("");
puts("post:");
preOrder(1,16);

puts("");
puts("pre:");

postOrder(1,16);



    return 0;
}
