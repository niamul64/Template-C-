#include<stdio.h>
struct mynode
{
    int value;
    struct mynode *left,*right;
};
struct mynode *root=NULL;
int total;


void insert(int x)
{
    struct mynode *i,*k;
    char lr;
    if(root ==NULL)
    {
        struct mynode *st=malloc(sizeof(struct mynode));
        st->value=x;
        st->left=NULL;
        st->right=NULL;
        root=st;
        return;
    }
    for(i=root; ;)
    {
        if(i==NULL)
        {
            struct mynode *st=malloc(sizeof(struct mynode));
            st->value=x;
            st->left=NULL;
            st->right=NULL;
            if(lr=='l')
            {
                k->left=st;
            }
            else
            {
                k->right=st;

            }
            break;
        }
        else if(x>i->value)
        {
            k=i;
            i=i->right;
            lr='r';
        }
        else if(x<i->value)
        {
            k=i;
            i=i->left;
            lr='l';
        }
    }
}
void delete_(x)
{
    struct mynode *i,*k;
 char lr='0';
    if(root ==NULL)
    {
        puts("not found");
        return;
    }
    for(i=root; ;)
    {
        if(i==NULL)
        {
            puts("Not found");
            return;
        }
        else if(i->value==x)
        {

           if((i->left==NULL && i->right!=NULL) || (i->right==NULL && i->left==NULL)){
            printf("%d matched and removed",i->value);
           if(lr=='l')
           {
               if(i->left!=NULL){
               k->left=i->left;
               }
               else
               k->left=i->right;

           }
           else if(lr=='r')
           {

               if(i->left!=NULL){
               k->right=i->left;
               }
               else
               k->right=i->right;

           }
           }
           else if (i->left==NULL && i->right!=NULL){
                printf("%d matched and removed",i->value);
             i=NULL;
           free(i);
           if(lr=='l')
           {
               k->left=NULL;

           }
           else if(lr=='r')
           {

               k->right=NULL;

           }

           }
           else{
            puts("can't be removed");
           }

           return;
        }
        else if(x>i->value)
        {
           k=i;
            i=i->right;
          lr='r';

        }
        else if(x<i->value)
        {
            lr='l';
            k= i;
            i=i->left;
        }
    }
}
void Inorder(struct mynode *i)
{

    if (i== NULL )
        return;
    else
    {
        struct mynode *le=i->left;
        struct mynode *ri=i->right;
        Inorder(le);
        printf("%d ",i->value);

        Inorder(ri);

    }
}

void preorder(struct mynode *i)
{

    if (i== NULL )
        return;
    else
    {
        struct mynode *le=i->left;
        struct mynode *ri=i->right;
        printf("%d ",i->value);
        preorder(le);
        preorder(ri);
    }
}

void postorder(struct mynode *i)
{

    if (i== NULL )
        return;
    else
    {
        struct mynode *le=i->left;
        struct mynode *ri=i->right;

        postorder(le);
        postorder(ri);
        printf("%d ",i->value);
    }
}




int main()
{
    int x;
    char y;
    while(1)
    {
        scanf("%d%c",&x,&y);

        insert(x);
        if(y=='\n')
            break;

    }


    puts("");
    puts("which value you want to delet");
    scanf("%d",&x);
    delete_(x);
    puts("");
    puts("Now: ");
    puts("Inorder:");
    Inorder(root);

    puts("");
    puts("PreOrder:");
    preorder(root);

    puts("");
    puts("PostOrder:");
    postorder(root);
    puts("");




    return 0;
}
