#include<stdio.h>
struct mynode
{

    int value;
    struct mynode *left,*right;


};
struct mynode *root=NULL;
int total;


void insert(int x)
{
    struct mynode *i,*k;
    char lr;
    if(root ==NULL)
    {
        struct mynode *st=malloc(sizeof(struct mynode));
        st->value=x;
        st->left=NULL;
        st->right=NULL;
        root=st;
        return;
    }
    for(i=root; ;)
    {
        if(i==NULL)
        {
            struct mynode *st=malloc(sizeof(struct mynode));
            st->value=x;
            st->left=NULL;
            st->right=NULL;
            if(lr=='l')
            {
                k->left=st;


            }
            else
            {
                k->right=st;

            }

            break;
        }
        else if(x>i->value)
        {
            k=i;
            i=i->right;
            lr='r';
        }
        else if(x<i->value)
        {
            k=i;
            i=i->left;
            lr='l';
        }

    }
}

int main()
{
    int x;
    char y;
    while(1)
    {
        scanf("%d%c",&x,&y);
        if(y=='\n')
            break;
        insert(x);

    }






    return 0;
}
