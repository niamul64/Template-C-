
#include<stdio.h>
int a[10000];
int i;

void inOrder(int i, int Size)
{
    if (a[i]== 0  || i>=Size)
        return;
    else
    {
        int left=2*i;
        int right=2*i+1;
        inOrder(left,Size);
        printf("%d ", a[i]);

        inOrder(right,Size);

    }
}
void postOrder(int i, int Size)
{


    if (a[i]== 0  || i>=Size)
        return;
    else
    {
        int left=2*i;
        int right=2*i+1;
        postOrder(left,Size);
        postOrder(right,Size);
        printf("%d ", a[i]);

    }

}
void preOrder(int i, int Size)
{


    if (a[i]== 0  || i>=Size)
        return;
    else
    {
        int left=2*i;
        int right=2*i+1;
        printf("%d ", a[i]);
        preOrder(left,Size);
        preOrder(right,Size);


    }

}
void inputcheck(int node,int root,int size)
{
    if(a[root]==0)
    {
        a[root]=node;
        return;
    }

    int  left=root*2;
    int  right=root*2+1;
    if(node>a[root])
    {
        inputcheck( node,right, size);
    }
    else if(node<a[root])
    {
        inputcheck( node, left, size);
    }
}

int main()
{
    int size;
    puts("Enter the size if the arry :");
    scanf("%d",&size);


    for(i=0; i<size; i++)
    {
        int x;
        scanf("%d",&x);
        inputcheck(x,1,i);

    }
    int j;
    for(j=1;j<=16;j++)
    {
        printf("%d ",a[j]);
    }




    return 0;
}
